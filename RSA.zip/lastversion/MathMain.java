public class MathMain { 
   public static void main(String[] args) { 
   
   
      RSA test = new RSA(); 
   
   //Test method extended-Euclid
      System.out.println("\n------ TEST METHOD EXTENDED EUCLID ------"); 
      System.out.println("-----------------------------------------------\n"); 
      System.out.print("The Extended-Euclid of 91 , 287 is : "); 
      long gc[]=test.extended_Euclid(91,287);
      System.out.println(gc[2]); 
      System.out.println("-----------------------------------------------\n"); 
   
   
   //Test method find_inverse
      System.out.println("\n------ TEST METHOD FIND INVERSE ------"); 
      System.out.println("-----------------------------------------------\n"); 
      System.out.print("The find_inverse of 101 , 4620 is : "); 
      System.out.println(test.find_inverse(101,4620)); 
      System.out.println("-----------------------------------------------\n"); 
   
   
   //Test string_to_int
      System.out.println("\n------ TEST METHOD STRING TO INT ------"); 
      System.out.println("-----------------------------------------------\n"); 
      System.out.print("The Convert of TEXT (DISCRETEMATH) to INTEGER : "); 
   
      long a = test.string_to_int("DISCRETE");
      long b = test.string_to_int("MATH");
   
      String aa = ""+a;
      String bb = ""+b;
      aa=aa.substring(1,aa.length());
      bb=bb.substring(1,bb.length());
   
      System.out.println(aa+bb); 
      System.out.println("-----------------------------------------------\n"); 
   
   
   //Test int_to_String
   
      System.out.println("\n------ TEST METHOD INT TO STRING ------"); 
      System.out.println("-----------------------------------------------\n"); 
      String aaa=""+a;
      String bbb=""+b;
      System.out.printf("The Convert of INT %s%s to STRING : ",aaa.substring(1,aaa.length()),bbb.substring(1,bbb.length())); 
      String a1 = test.int_to_String(a);
      String b1 = test.int_to_String(b);
      System.out.println(a1+b1); 
      System.out.println("-----------------------------------------------\n"); 
   
   
   //Test random_prime 
   
      System.out.println("\n------ TEST METHOD RANDOM PRIME ------"); 
      System.out.println("-----------------------------------------------"); 
      int prime = test.random_prime();
      System.out.printf("The Random prime : %d \n",prime); 
      System.out.println("\n-----------------------------------------------\n"); 
   
   
   //Test isPrime 
   
      System.out.println("\n------ TEST METHOD IS PRIME ------"); 
      System.out.println("-----------------------------------------------\n"); 
      System.out.printf("  is %d prime ? %b ",prime,test.isPrime(prime)); 
      System.out.println("\n-----------------------------------------------\n"); 
   
   
   
   
   //Test modular_exponentiation
   
      System.out.println("\n------ TEST METHOD MODULAR EXPONENTIATION ------"); 
      System.out.println("-----------------------------------------------\n"); 
      System.out.printf("1- 3 power 200 mod 50 = %d \n\n",test.modular_exponentiation(3,200,50)); 
      System.out.printf("2- 3 power 94 mod 17 = %d \n\n",test.modular_exponentiation(3,94,17)); 
      System.out.printf("3- 3 power 644 mod 645 = %d \n\n",test.modular_exponentiation(7,644,645)); 
   
      System.out.println("-----------------------------------------------");
   
   
   
   //Test generate_keys() 
   
      System.out.println("\n------ TEST METHOD GENERATE KEYS ------"); 
      System.out.println("-----------------------------------------------\n"); 
   
      long[] araayskays = test.generate_keys();
      System.out.println("\n**PUBLIC KEYS**");
      System.out.printf("\nexponent =%d\n",araayskays[0]);
      System.out.printf("\nn=%d\n",araayskays[1]);
      System.out.printf("\n**PRIVATE KEYS**\n");
      System.out.printf("\nd=%d\n",araayskays[2]);
      System.out.println("\n-----------------------------------------------\n");
   
   
   
   //Test encrypt
      System.out.println("\n------ TEST METHOD ENCRYPT ------"); 
      System.out.println("-----------------------------------------------"); 
      System.out.printf("Encrypt the massage STOP using RSA cryptosystem with key(%d,%d) \n" ,araayskays[0],araayskays[1]); 
      long[] encryptmassage = test.encrypt("STOP",araayskays[0],araayskays[1]);
      for ( int i = 0 ; i < encryptmassage.length ; i++ )
         System.out.print(encryptmassage[i]+" ");
   
   
      System.out.println("\n-----------------------------------------------\n");
   
   
   
   //Test decrypt 
   
      System.out.println("\n------ TEST METHOD DECRYPT ------"); 
      System.out.println("-----------------------------------------------\n");
      System.out.printf("The decrypt of before massage is : %s \n" , test.decrypt(encryptmassage,araayskays[2],araayskays[1])); 
   
   } 
} 
