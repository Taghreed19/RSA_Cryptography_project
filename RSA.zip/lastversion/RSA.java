import java.lang.Character.*;
public class RSA{


//1 done
   public static long[] extended_Euclid(long p, long q){
      if(q<p){
      long t=p;
       p=q; 
       q=t;}
       if(q%p==0){
       long[] result={1,0,p};
       return result;}
       else{
       long[] e = extended_Euclid(q%p,p);
       long a=e[0];
       long b=e[1];
       long c=e[2];
       long result[]={(b-(q/p)*a),a,c};
      
         return result;
     }
}

//2 done
   public static long find_inverse(long a , long m ) { 
   
      long x[] = extended_Euclid(a,m);
   
      for ( int i = 1 ; i<m ;i++ ){ 
         if ( (a*i-1)%m == 0)
            return i ; }
     
   
      return 0; //means no inverse
   }

//3 done
   public static int random_prime(){
   
      int rand = (int)(Math.random() * 1000);
      while(!isPrime(rand))
         rand = (int)(Math.random() * 1000);
      return rand;
   }

//4 done
   public static boolean isPrime(long p){
      long f=(long)Math.pow(p, 0.5);
      for(long i=2;i<=f;i++)
         if(p%i==0)
            return false;
      return true;
   }



//5 done


      
   public long[] generate_keys(){
      long [] numbers=new long[3] ;
      long e = random_prime();
      long p = random_prime();
      long q= random_prime();
      long n =p*q;
      
      long a = (p-1)*(q-1);      
      long gcd[] = extended_Euclid(e,a);
      long d=find_inverse(e , a);
      
      while (e>a&&gcd[2]!=1&&e<1)
         e=random_prime();
         
     
      numbers[0]=e; //exponent
      numbers[1]=n; //public kays
      numbers[2]=d; //private kays
      
      return numbers;
   }
   
//6  done

   public static long modular_exponentiation(long b, long n, long m){
   
      long x=1;
      long power=b%m;
      while(n > 0){
         if(n%2 == 1){
            x=(x*power)%m;
         }
         power = (power*power)%m; 
         n /= 2;
      }
      return  x%m;
    
   
   }

//7 done
   public long string_to_int(String text) { 
   
      char a ; 
      long number = 0;
      String numverString = "" ;
      for ( int i = 0 ; i<text.length() ; i++) { 
      
         a = text.charAt(i); 
      
         if ( Character.isLowerCase(a) )
            number = (a-65-32);
         else 
            number = (a-65);
      
         if ( number < 10 ) {
            String n = "0"+number;
            numverString = numverString+n;
         }
         else 
            numverString = numverString+number;
      
      }
      numverString = "1"+numverString;
      number = Long.parseLong(numverString);
      return number;
   }


//8 done
public String int_to_String(long inttext)
      {
      String text="";
      long num=0;
      while(inttext>1){
      num= inttext%100;
      text = String.valueOf((char)(num+65))+text;
      inttext = inttext/100;
      }
      return text;

      }


//9 done 
   public long[] encrypt ( String plaintext , long e , long n ) {
     
      String s="25";
      int len;
      while(true){
         if(Long.parseLong(s)<n && n<Long.parseLong(s+s))
            break;
         else
            s+=s;}
      if(plaintext.length()%2==1)
         len= (plaintext.length())/(s.length()/2)+1;
      else
         len= (plaintext.length())/(s.length()/2);
      String blocks[]=new String[len];
      for(int i=0;i<len;i++){
         if(i+1!=len)
            blocks[i]=plaintext.substring(0,s.length()/2);
         else
            blocks[i]=plaintext.substring(0);
      }
      long m,c[]= new long[plaintext.length()]; 
      for(int i=0;i<blocks.length;i++){
         m=string_to_int(blocks[i]);
         c[i]=modular_exponentiation(m%((long)(Math.pow(10,s.length()))),e,n);
      }
      return c;
   }
   
   //10 done
   String decrypt(long[] ciphertext, long d, long n){
      long m, c ; 
      String dec="";
      for(int i=0;i<ciphertext.length;i++){
      
      
         c=modular_exponentiation(ciphertext[i],d,n);
         
         dec+=int_to_String(c);
      
      }
      return dec;
   }


}